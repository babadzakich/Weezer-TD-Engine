=== LEVEL PACKAGE ===

Level ID: level_1
Level Name: Level 1
Map Size: 3000 x 2000

STATISTICS:
- Spawn Points: 1
- Defense Points: 1
- Paths: 0
- Build Zones: 2
- Waves: 1
- Enemy Types: 0

CONTENTS:
Maps/
  - level_1.json           : Map data (spawns, defense, paths, build zones)
  - level_1.waves.json     : Wave configurations
  - Enemies/                : Enemy configurations and source files
  - Towers/                 : Tower configurations and source files
  - DamageDealers/          : Damage dealer configurations and source files

Generated: 2026-01-24 21:11:29
